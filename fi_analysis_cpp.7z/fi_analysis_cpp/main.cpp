
import std;

#include "json.hpp"

namespace fs = std::filesystem;
namespace rng = std::ranges;
namespace vw = std::views;
namespace chr = std::chrono;


using namespace std::literals;

namespace {
  constexpr bool kEnableWarning{false};
  constexpr bool kEnableProfiling{false};
  constexpr bool kSerializeRecords{false};
}


enum class MiBenchProgram {kNone, kRijndael, kQsort, kSha, kBlowfish, kDijkstra, kStringsearch, kBitcount, kCrc};
auto to_string(MiBenchProgram mibench_program) {
  using enum MiBenchProgram;

  static std::unordered_map<MiBenchProgram, std::string_view> const kMpToSv{
    {kRijndael, "Rijndael"sv},
    {kQsort, "Qsort"sv},
    {kSha, "Sha"sv},
    {kBlowfish, "Blowfish"sv},
    {kDijkstra, "Dijkstra"sv},
    {kStringsearch, "Stringsearch"sv},
    {kBitcount, "Bitcount"sv},
    {kCrc, "Crc"sv}
  };

  try {
    return std::string{kMpToSv.at(mibench_program)};
  } catch (std::out_of_range const& ex) {
    std::println("mibench_program: {} is not known yet.", std::to_underlying(mibench_program));
    throw;
  }
}

enum class FaultOutcome {kNone, kAppMasked, kAppMaskedCfd, kEdc, kEdcCfd, kHang, kHangCfd, kLat, kLatCfd, kLatTwoCfd, kUt, kUtCfd, kUtSwd, kMicroArchMasked, kUtSwdCfd, kEdcSwd};
auto StringToFaultOutcome(std::string_view fault_outcome_sv) {
  using enum FaultOutcome;

  static std::unordered_map<std::string_view, FaultOutcome> const sv_to_fo_map{
    {"uAM"sv, kMicroArchMasked},
    {"APPM"sv, kAppMasked},
    {"LAT"sv, kLat},
    {"EDC"sv, kEdc},
    {"UT"sv, kUt},
    {"H"sv, kHang},
    {"H_CFD"sv, kHangCfd},
    {"APPM_CFD"sv, kAppMaskedCfd},
    {"UT_SWD"sv, kUtSwd},
    {"LAT_CFD"sv, kLatCfd},
    {"LAT2_CFD"sv, kLatTwoCfd},
    {"EDC_CFD"sv, kEdcCfd},
    {"UT_SWD_CFD"sv, kUtSwdCfd},
    {"EDC_SWD"sv, kEdcSwd},
    {"UT_SWD_CFD"sv, kUtSwdCfd},
    {"UT_CFD"sv, kUtCfd}
  };

  try {
    return sv_to_fo_map.at(fault_outcome_sv);
  } catch (std::out_of_range const& ex) {
    std::println("FaultOUtcome::{}, not yet known", fault_outcome_sv);
    throw;
  }
} 

enum class SystemLevelEffect {kNone, kDue, kMasked, kSdc, kSdcCfd};
auto StringToSystemLevelEffect(std::string_view sle_sv) {
  using enum SystemLevelEffect;

  static std::unordered_map<std::string_view, SystemLevelEffect> const sv_to_sle_map{
    {"F", kDue},
    {"NE", kMasked},
    {"SDCF", kSdc},
    {"SDCF_C", kSdcCfd},
    {"", kNone}
  };

  try {
    return sv_to_sle_map.at(sle_sv);
  } catch (std::out_of_range const& ex) {
    std::println("{} not yet known", sle_sv);
    throw;
  }
}

enum class ErrorKind {kNone, kDataflow, kControlFlow, kHybrid};
auto StringToErrorKind(std::string_view error_sv) {
  using enum ErrorKind;

  static std::unordered_map<std::string_view, ErrorKind> const error_to_ek_map{
    {"", kNone},
    {"_CFE", kControlFlow},
    {"_DFE", kDataflow},
    {"_CFE_DFE", kHybrid}
  };

  try {
    return error_to_ek_map.at(error_sv);
  } catch (std::out_of_range const& ex) {
    std::println("{} not yet known", error_sv);
    throw;
  }
}

struct Record {
  FaultOutcome fault_outcome{FaultOutcome::kNone};
  SystemLevelEffect system_level_effect{SystemLevelEffect::kNone};
  ErrorKind error_kind{ErrorKind::kNone};
  std::uint64_t id{0};

  auto Print() const {
    try {
      std::println("{} | {} | {} | {}", id, kFoToSv.at(fault_outcome), kSleToSv.at(system_level_effect), kEkToSv.at(error_kind));
    } catch (std::exception const& ex) {
      std::println("id: {}, fo: {}, sle: {}, ek: {}", id, std::to_underlying(fault_outcome), std::to_underlying(system_level_effect), std::to_underlying(error_kind));
      throw;
    }
  }

  auto IsArtifact() const {
    return ((error_kind == ErrorKind::kNone and (system_level_effect == SystemLevelEffect::kSdc or system_level_effect == SystemLevelEffect::kSdcCfd)) or 
            (fault_outcome == FaultOutcome::kLat or fault_outcome == FaultOutcome::kLatTwoCfd or fault_outcome == FaultOutcome::kLatCfd));
  }

  static inline std::unordered_map<FaultOutcome, std::string_view> const kFoToSv{
    {FaultOutcome::kNone, "None"sv},
    {FaultOutcome::kAppMasked, "APPM"sv},
    {FaultOutcome::kAppMaskedCfd, "APPM_CFD"sv},
    {FaultOutcome::kEdc, "EDC"sv},
    {FaultOutcome::kEdcCfd, "EDC_CFD"sv},
    {FaultOutcome::kHang, "HANG"sv},
    {FaultOutcome::kHangCfd, "HANG_CFD"sv},
    {FaultOutcome::kLat, "LAT"sv},
    {FaultOutcome::kLatCfd, "LAT_CFD"sv},
    {FaultOutcome::kLatTwoCfd, "LAT2_CFD"sv},
    {FaultOutcome::kUt, "UT"sv},
    {FaultOutcome::kUtCfd, "UT_CFD"sv},
    {FaultOutcome::kUtSwd, "UT_SWD"sv},
    {FaultOutcome::kUtSwdCfd, "UT_SWD_CFD"sv},
    {FaultOutcome::kEdcSwd, "EDC_SWD"sv},
    {FaultOutcome::kUtSwdCfd, "UT_SWD_CFD"sv},
    {FaultOutcome::kMicroArchMasked, "UAM"sv}
  };
  static inline std::unordered_map<SystemLevelEffect, std::string_view> const kSleToSv{
    {SystemLevelEffect::kNone, "None"sv},
    {SystemLevelEffect::kDue, "DUE"sv},
    {SystemLevelEffect::kMasked, "Masked"sv},
    {SystemLevelEffect::kSdc, "SDC"sv},
    {SystemLevelEffect::kSdcCfd, "SDC_CFD"sv}
  };
  static inline std::unordered_map<ErrorKind, std::string_view> const kEkToSv {
    {ErrorKind::kNone, "None"sv},
    {ErrorKind::kDataflow, "DFE"sv},
    {ErrorKind::kControlFlow, "CFE"sv},
    {ErrorKind::kHybrid, "DFE_CFE"sv}
  };
};

auto to_json(nlohmann::json & json, Record const& record) {
  json = {
    {"id", record.id},
    {"fault_outcome", std::to_underlying(record.fault_outcome)},
    {"system_level_effect", std::to_underlying(record.system_level_effect)},
    {"error_kind", std::to_underlying(record.error_kind)}
  };
}

auto to_json(nlohmann::json & json, std::vector<Record> const& records) {
  rng::transform(records, std::back_inserter(json), [](auto const& record) {
      nlohmann::json record_j = record;
      return record;
    });
}

auto from_json(nlohmann::json const& json, Record & record) {
  record.id = json.at("id").get<std::uint64_t>();
  record.fault_outcome = static_cast<FaultOutcome>(json.at("fault_outcome").get<std::underlying_type_t<FaultOutcome>>());
  record.system_level_effect = static_cast<SystemLevelEffect>(json.at("system_level_effect").get<std::underlying_type_t<SystemLevelEffect>>());
  record.error_kind = static_cast<ErrorKind>(json.at("error_kind").get<std::underlying_type_t<ErrorKind>>());
}

auto from_json(nlohmann::json const& json, std::vector<Record> & records) {
  rng::transform(json, std::back_inserter(records), [](auto const& record_j) {
      Record record = record_j;
      return record;
    });
}


class LogStats final {
  public:
    explicit LogStats(MiBenchProgram mibench_program) : m_mibench_program{mibench_program} {
      m_records.reserve(300'000UZ);
    }

    auto LoadRecords(std::vector<std::string_view>&& log_dirs) {
      auto log_filter{
        [](fs::directory_entry const& dir_entry) -> bool {
          std::string_view const dir_entry_name{dir_entry.path().c_str()};
          return (dir_entry.is_regular_file() and dir_entry_name.ends_with("_log"));
        }
      };

      for (auto const& log_dir : log_dirs) {
        std::ranges::for_each(fs::directory_iterator{log_dir} | vw::filter(log_filter),
            [this](auto const& dir_entry) {
              CaptureStatsFromLogFile(dir_entry.path().c_str());
            });
      }
    }

    auto LoadRecordsFromJson(std::string_view records_j_path) {
      nlohmann::json records_j{};
      std::ifstream records_ifs{records_j_path};
      records_ifs >> records_j;

      m_records = records_j;
    }

    auto SerializeRecords() const {
      nlohmann::json records_j = m_records;
      std::ofstream records_ofs{to_string(m_mibench_program) + "_records.json"s};
      records_ofs << std::setw(4) << records_j; 
    }

    auto PrintDues() const {
      rng::for_each(m_records | vw::filter([](auto const& record) { return (record.system_level_effect == SystemLevelEffect::kDue and record.error_kind != ErrorKind::kNone); }), 
          [](auto const& record) {
            record.Print();
          });
    }

    auto GetNumberOfFaults() const {
      return m_records.size();
    }

    auto GetRateHelper(auto quantity) const {
      return ((static_cast<std::size_t>(quantity) / static_cast<double>(GetNumberOfFaults())));
    }

    auto GetRawCount(auto count_if_functor) const {
      return rng::count_if(m_records, count_if_functor);
    }

    auto PrintSpecificRecords(auto print_functor) const {
      rng::for_each(m_records | vw::filter(print_functor), [](auto const& record) { record.Print(); });
    }

    auto GetRate(auto count_if_functor) const -> double {
      return GetRateHelper(GetRawCount(count_if_functor));
    }

  private:
    auto CaptureStatsFromLogFile(std::string_view log_file_path) -> void {
      std::vector<char> log_file_data{};

      auto get_view_over_file_data{
        [&log_file_data, &log_file_path]() {
          std::ifstream ifs{log_file_path};
          rng::copy(std::istreambuf_iterator<char>{ifs}, std::istreambuf_iterator<char>{}, std::back_inserter(log_file_data)); 
          return std::string_view{log_file_data};
        }
      };


      auto const file_data_sv{get_view_over_file_data()};

      auto find_value_for_key{
        [file_data_sv](std::string_view key) -> std::string_view {
          static constexpr std::size_t kKeySize{4};

          auto const pos{file_data_sv.find(key)};
          if (pos == std::string_view::npos) {
            throw std::runtime_error{std::format("No key: `{}` exists.", key)};
          }

          auto const start{pos + kKeySize};
          auto const end{file_data_sv.find_first_of("\n"sv, start)};
          return file_data_sv.substr(start, end - start);
        }
      };

      try {
        auto const fault_outcome{StringToFaultOutcome(find_value_for_key("FO:"))};
        auto const system_level_outcome{StringToSystemLevelEffect(find_value_for_key("SL:"))};
        auto const error_kind{StringToErrorKind(find_value_for_key("FE:"))};
        auto const id{static_cast<std::uint64_t>(std::stoi(std::string{log_file_path.substr(log_file_path.find_last_of("/"sv) + 6, 6)}))};

        Record const record{.fault_outcome = fault_outcome, .system_level_effect = system_level_outcome, .error_kind = error_kind, .id = id};
        if (record.IsArtifact()) {
          m_ignored_records.push_back(record);
        } else {
          m_records.push_back(record);
        }
      } catch (std::exception const& ex) {
        if constexpr (kEnableWarning) {
          std::println("[WARNING] Could not create record for logfile: {}", log_file_path);
        }

        return;
      }
    }

    std::vector<Record> m_records{};
    std::vector<Record> m_ignored_records{};
    MiBenchProgram m_mibench_program{MiBenchProgram::kNone};
};


auto main() -> int {
  using enum MiBenchProgram;

  auto compute_sdc_probabilities {
    [](LogStats const& log_stats) -> std::pair<double, double> {
      auto const sdc_filter{[](auto const& record) {
          return (record.system_level_effect == SystemLevelEffect::kSdc or record.system_level_effect == SystemLevelEffect::kSdcCfd);
      }};
      auto const p_sdc{log_stats.GetRate(sdc_filter)};

      auto const p_sdcAndDfe{log_stats.GetRate([&sdc_filter](auto const& record) {return (sdc_filter(record) and record.error_kind == ErrorKind::kDataflow);})};
      auto const p_dfeGivenSdc{p_sdcAndDfe / p_sdc};
      auto const p_sdcAndCfe{log_stats.GetRate([&sdc_filter](auto const& record) {return (sdc_filter(record) and record.error_kind != ErrorKind::kDataflow);})};
      auto const p_cfeGivenSdc{p_sdcAndCfe / p_sdc};

      return {p_cfeGivenSdc, p_dfeGivenSdc};
    }};

  auto compute_due_probabilities {
    [](LogStats const& log_stats) -> std::pair<double, double> {
      auto const due_filter{[](auto const& record) { return record.system_level_effect == SystemLevelEffect::kDue; }};
      auto const p_due{log_stats.GetRate(due_filter)};
      
      auto const p_dueAndDfe{log_stats.GetRate([&due_filter](auto const& record) { return (due_filter(record) and record.error_kind == ErrorKind::kDataflow); })};
      auto const p_dfeGivenDue{p_dueAndDfe / p_due};
      auto const p_dueAndCfe{log_stats.GetRate([&due_filter](auto const& record) { return (due_filter(record) and record.error_kind != ErrorKind::kDataflow); })};
      auto const p_cfeGivenDue{p_dueAndCfe / p_due};

      return {p_cfeGivenDue, p_dfeGivenDue};
    }
  };


  std::ofstream latextablefs{"latextable.txt"};

  /*
  std::unordered_map<MiBenchProgram, std::vector<std::string_view>> dataset_paths{
    {kRijndael, {"/home/ush/fi_sim_data/fi_sim_data/aes/aes.O2.or1k_240220211314_1/ml/"sv}},
    {kSha, {"/home/ush/fi_sim_data/fi_sim_data/sha/sha.O2.or1k_230220211539_1/ml/"sv,"/home/ush/fi_sim_data/fi_sim_data/sha/sha.O2.or1k_230220211539_2/ml/"sv}},
    {kBlowfish, {"/home/ush/fi_sim_data/fi_sim_data/bf/bf.O2.or1k_220220211716_1/ml/"sv, "/home/ush/fi_sim_data/fi_sim_data/bf/bf.O2.or1k_220220211716_2/ml/"sv}},
    {kDijkstra, {"/home/ush/fi_sim_data/fi_sim_data/dij/dij.O2.or1k_240220210214_1/ml/"sv, "/home/ush/fi_sim_data/fi_sim_data/dij/dij.O2.or1k_240220210214_2/ml/"sv}},
    {kStringsearch, {"/home/ush/fi_sim_data/fi_sim_data/ss/ss.O2.or1k_240220210532_1/ml/"sv, "/home/ush/fi_sim_data/fi_sim_data/ss/ss.O2.or1k_240220210532_2/ml/"sv}},
    {kBitcount, {"/home/ush/fi_sim_data/fi_sim_data/bc/bc.O2.or1k_240220210737_1/ml/"sv, "/home/ush/fi_sim_data/fi_sim_data/bc/bc.O2.or1k_240220210737_2/ml/"sv}},
    {kCrc, {"/home/ush/fi_sim_data/fi_sim_data/crc/crc.O2.or1k_240220211629_1/ml/"sv, "/home/ush/fi_sim_data/fi_sim_data/crc/crc.O2.or1k_240220211629_2/ml/"sv}},
    {kQsort, {"/home/ush/fi_sim_data/fi_sim_data/qs/qs.O2.or1k_230220210322_1/ml/"sv, "/home/ush/fi_sim_data/fi_sim_data/qs/qs.O2.or1k_230220210322_2/ml/"sv}}
  };

  for (auto&& [k,v] : dataset_paths) {
    LogStats log_stats{k};

    auto start{chr::high_resolution_clock::now()};
    log_stats.LoadRecords(std::move(v));
    if constexpr (kEnableProfiling) {
      std::println("[PROFILE] LogStats construction consumed {:6} seconds.", chr::duration<double>{chr::high_resolution_clock::now() - start});
    }

    if constexpr (kSerializeRecords) {
      log_stats.SerializeRecords();
    }

    auto const p_givenSdc{compute_sdc_probabilities(log_stats)};
    auto const p_givenDue{compute_due_probabilities(log_stats)};
    latextablefs << std::format("\\texttt{{{}}} & {:.4f} & {:.4f} & {:.4f} & {:.4f} \\\\ \n", to_string(k), p_givenSdc.first, p_givenSdc.second, p_givenDue.first, p_givenDue.second);
  }
  */

  for (auto program : vw::iota(std::to_underlying(MiBenchProgram::kNone) + 1, std::to_underlying(MiBenchProgram::kCrc) + 1)) {
    auto mibench_program{static_cast<MiBenchProgram>(program)};
    LogStats log_stats{mibench_program};

    auto start{chr::high_resolution_clock::now()};
    log_stats.LoadRecordsFromJson(to_string(mibench_program) + "_records.json"s);
    if constexpr (kEnableProfiling) {
      std::println("[PROFILE] LogStats construction consumed {:6} seconds.", chr::duration<double>{chr::high_resolution_clock::now() - start});
    }

    auto const p_givenSdc{compute_sdc_probabilities(log_stats)};
    auto const p_givenDue{compute_due_probabilities(log_stats)};
    latextablefs << std::format("\\texttt{{{}}} & {:.4f} & {:.4f} & {:.4f} & {:.4f} \\\\ \n", to_string(mibench_program), p_givenSdc.first, p_givenSdc.second, p_givenDue.first, p_givenDue.second);
  }
}


// In our VP simulations, we rely on ETISS fault classifier to list a bitflip as causing a DFE or CFE. Internally when a bitflip occurs, the ETISS simulator has logic to 
// detect if a CFE or DFE occurred. We rely on it. Considering this feature was requested by DMG and he has this definition:
// - CFE : CFG was violated
// - DFE : CFG was intact
// We stick to this concept in our research as well.

