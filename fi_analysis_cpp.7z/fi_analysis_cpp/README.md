# Compile
```
# Need clang v17
clang++ -O3 -stdlib=libc++ -fmodules -std=c++26 main.cpp -o file_parser && ./file_parser 
```
